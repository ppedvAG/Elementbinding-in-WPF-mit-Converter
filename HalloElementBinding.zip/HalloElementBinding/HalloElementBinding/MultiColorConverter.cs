﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace HalloElementBinding
{
    class MultiColorConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
      
            byte redbyte = System.Convert.ToByte(values[0]);
            byte greenbyte = System.Convert.ToByte(values[1]);
            byte bluebyte = System.Convert.ToByte(values[2]);
            SolidColorBrush mycolor = new SolidColorBrush();

            mycolor.Color = Color.FromRgb(redbyte, greenbyte, bluebyte);

            return mycolor;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
